wget http://rusvectores.org/static/models/ruwikiruscorpora_0_300_20.bin.gz -O ruwikiruscorpora_0_300_20.bin.gz
